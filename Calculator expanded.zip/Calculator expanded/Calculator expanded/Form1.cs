﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Calculator_expanded
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        // Input
        private void textBox2_TextChanged(object sender, EventArgs e) 
        {
            
        }

        //Result 
        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        //Big button til at udregne det hele
        private void button1_Click(object sender, EventArgs e)
        {

            string test = textBox2.Text; //Her er inputet fra textboxen til venstre gemt i en string
                                 
            if (test.Contains('+')) // hvis string "test" indeholder et (char) + skal den gå ind i if statementen
            {                
               string[] array = test.Split('+'); // Splitter string "test" ved '+' og gemmer tallene i et string array
               double testSum = 0; //sum sættes til 0

                for (int i = 0; i < array.Length; i++) // for-loop der gør det muligt at have flere af den samme operator 
                {
                double test1 = Convert.ToDouble(array[i]); // Array index{0}, {1} osv gemmes i en double "test1"
                testSum += test1;                           // test1 lægges til Sum: 0 + {0} + {1} osv
                string testStr = Convert.ToString(testSum); // Sum laves om til en string
                textBox4.Text = testStr;                    // sum i string format sendes til textboxen til højre
                }
            }            

            else if (test.Contains('-'))
            {
                string[] array = test.Split('-');
                double testSum = Convert.ToDouble(array[0]);  // Sum sættes til det første index i array'et. Altså det første nummer. 
                
                
                for (int i = 1; i < array.Length; i++) // for-loop der starter ved index nr 2 {1}
                {
                    double test1 = Convert.ToDouble(array[i]); // Array index{1} gemmes i test1
                    testSum = testSum - test1;                  // {1} trækkes fra {0} og gemmes is testSum
                    string testStr = Convert.ToString(testSum); //TestSum laves om til en string "testStr"
                    textBox4.Text = testStr;                    // sum i string format sendes til textboxen til højre
                }
            }

            else if (test.Contains('*'))
            {
                string[] array = test.Split('*');
                double testSum = 1;                             // Sum sættes til 1, for hvis der ganges med 0 så er resultatet altid 0.
                for (int i = 0; i < array.Length; i++)          // Loopet er identisk til + for-loopet. Bortset fra at det ganger i stedet
                {
                    double test1 = Convert.ToDouble(array[i]);
                    testSum *= test1;
                    string testStr = Convert.ToString(testSum);
                    textBox4.Text = testStr;
                }
            }

            else if (test.Contains('/'))
            {
                if (test.Contains("/0"))                         // hvis stringen test indeholder /0 udregnes det ikke. 
                {                                                // Vi må nemmelig ikke dividere med 0 ;)
                    textBox4.Text = "Universe exploded";         // Så eksplodere universet !!!!!!
                }
                else {
                    string[] array = test.Split('/');
                    double testSum = Convert.ToDouble(array[0]);


                    for (int i = 1; i < array.Length; i++)
                    {
                        double test1 = Convert.ToDouble(array[i]);
                        testSum = testSum / test1;
                        string testStr = Convert.ToString(testSum);
                        textBox4.Text = testStr;
                    }
                }
            }

            /*
             Koden nedenfor var en "beta" version af loopsne - trial and error 
             
            if (test.Contains('+'))
            {
                string[] array = test.Split('+');
                int test1 = Convert.ToInt32(array[0]);
                int test2 = Convert.ToInt32(array[1]);
                int result = test1 + test2;
                test = Convert.ToString(result);
                textBox4.Text = test;
            }

            else if (test.Contains('-'))
            {
                string[] array = test.Split('-');
                int test1 = Convert.ToInt32(array[0]);
                int test2 = Convert.ToInt32(array[1]);
                int result = test1 - test2;
                test = Convert.ToString(result);
                textBox4.Text = test;
            }

            else if (test.Contains('*'))
            {
                string[] array = test.Split('*');
                int test1 = Convert.ToInt32(array[0]);
                int test2 = Convert.ToInt32(array[1]);
                int result = test1 * test2;
                test = Convert.ToString(result);
                textBox4.Text = test;
            }
            else if (test.Contains('/'))
            {
                string[] array = test.Split('/');
                int test1 = Convert.ToInt32(array[0]);
                int test2 = Convert.ToInt32(array[1]);
                int result = test1 / test2;
                test = Convert.ToString(result);
                textBox4.Text = test;
            }
            Beta kode end.
            */


        }
        private void button1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) // Hvis ENTER knappen bliver tastet tager programmet det som at button1 bliver trykket på.
            {
                button1.PerformClick();
            }
            if (e.KeyCode == Keys.Shift) // SHIFT er ikke mulig at intaste, samme gælder for CTRL og hvis intet input er indtastet
            {
                e.Handled = true;
            }
            if (e.KeyCode == Keys.Control)
            {
                e.Handled = true;
            }
            if (Text.Length == 0)
            {
                e.Handled = true;
            }
            if (e.KeyCode == Keys.Delete) // Hvis der tastes på DELETE slettes alt i input feltet
            {
                e.Handled = false;
                textBox2.Clear();
            }

        }
        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar < '0' || e.KeyChar > '9') // Her bestemmes at medmindre input er mellem 0 og 9 accepteres det ikke
            {                 
                e.Handled = true;
            }
            if (e.KeyChar == '+' || e.KeyChar == '-' || e.KeyChar == '*' || e.KeyChar == '/') // + - * / er dog accepteret her
            {
                e.Handled = false;
            }
            if (e.KeyChar == '\b') // BACKSPACE er accepteret her
            {
                e.Handled = false;
            }
            if (e.KeyChar == ',') // Komma er accepteret her. 
            {
                e.Handled = false;
            }

            /* 
             Note til e.Handled

            e.Handled = true; fortæller programmet at "det her har jeg styr på, lad det være". 
            Altså, hvis den er sat til false skal programmet tage sig af det.
             */
          
        }

    }
}
